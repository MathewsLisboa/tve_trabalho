# Aula 2 ----
# Carregando pacotes -----

library(pacman)
pacman::p_load(tidyverse, hms, scales, ggplot2, lubridate, dplyr, readr, gridExtra,
               copula, fBasics, StableEstim, stabledist, PerformanceAnalytics,
               extRemes, ismev, evmix, extremis, DT, gdtools, kableExtra, VGAM, evd, 
               fExtremes, graphics, ggExtra, patchwork, bgumbel)

# --------------------------------------------------
# Dispersao e Histograma ----

#M = Facebook
#MI = Twitter

MI <- MI[1:982]
ggplot(mapping = aes(x = M, y = MI)) +
  stat_density2d(binwidth = 25,color = "#00688B") +
  geom_point(size = 1.6, shape = 20) +
  labs(x="Blocos maximos Facebook", y="Blocos maximos Twitter") +
  theme_bw()
ggsave("dispdens.png", width = 158, height = 93, units = "mm")


df <- data.frame(x = M, y = MI)
ggplot(df, aes(x, y)) + geom_point() + 
  theme_classic() +
  labs(x="Blocos maximos Facebook", y="Blocos maximos Twitter")

## FDA fornecida
pgev <- function(x, mu, sigma, qsi) {
  if (qsi != 0) {
    return( exp(-(1 + qsi*(x-mu)/sigma)^(-1/qsi)) )
  } else {
    return( exp(-exp(- (x-mu)/sigma)) )
  }
}

## Inversa da FDA (Quantil)
qgev <- function(q, mu, sigma, qsi) {
  if (qsi != 0) {
    return(mu - (sigma/qsi) * ( 1 - (-log(q))^(-qsi)) )
  } else {
    return(mu - sigma*log(-log(q))  )
  }
}

## Derivada da FDA (Densidade)
dgev <- function(x, mu, sigma, qsi) {
  if (qsi != 0) {
    return ( exp(-(1 + qsi*(x-mu)/sigma)^(-1/qsi)) *
               (1/qsi*(1 + qsi*(x-mu)/sigma)^(-1/qsi-1) ) * qsi/sigma )
  } else {
    return ( exp(-exp(- (x-mu)/sigma)) * (1/sigma)*(exp(- (x-mu)/sigma)) )
  }
}


# Gerar uma amostra de tamanho 100 de uma v.a. GEV
# Grafico Facebook M
# Pegar valores gerados na ultima aula, colocados no grafico histograma pelo MLE
# xi=qsi, sigma=beta, mu=mu

qsi1 = -0.033180969
sigma1 = 0.01267736
mu1 = 0.002676859

set.seed(123)
yM <- runif (100 , min = 0 , max =1)
amostraM <- qgev(yM, mu1, sigma1, qsi1)

par(mfrow = c(1,2))
hist(amostraM , probability = T , border = " black ",
     col = "#00688B", main ="", xlab =" Amostra Facebook", ylab = " Densidade ")
curve(dgev(x,qsi = qsi1,sigma=sigma1,mu = mu1), add = T , col = "black")

# Grafico Twitter MI
# Pegar valores gerados na ultima aula, colocados no grafico histograma pelo MLE
qsi2 = -0.06887585
sigma2 = 0.02431638
mu2 = 0.00344904

set.seed(123)
yMI <- runif (100 , min = 0 , max =1)
amostraMI <- qgev(yMI, mu2, sigma2, qsi2)

hist(amostraMI , probability = T , border = "black",
     col = "#00688B", main ="", xlab =" Amostra Twitter ", ylab = " Densidade ") 
curve(dgev(x,qsi = qsi2,sigma= sigma2,mu =  mu2), add = T , col = "black")
dev.off()

#Grafico Dispersao e histograma
plot1 <- ggplot(df, aes(x, y)) + geom_point() + 
  theme_classic() +
  labs(x="Blocos maximos Facebook", y="Blocos maximos Twitter")

am <- data.frame(amostraM,i =rep("i",100))
dens1 <- ggplot(am, aes(x=amostraM)) + 
  geom_histogram(colour="white", fill="#00688B",bins=12)+
  labs(x="", y="") +
  theme_bw()

ami <- data.frame(amostraMI,i=rep("i",100))
dens2 <- ggplot(ami, aes(x=amostraMI)) + 
  geom_histogram(colour="white", fill="#00688B",bins=12)+
  labs(x="", y="") +
  theme_bw() +
  coord_flip()

dens1 + plot_spacer() + plot1 + dens2 + 
  plot_layout(
    ncol = 2, 
    nrow = 2, 
    widths = c(4, 1),
    heights = c(1, 4)
  ) 
ggsave("disphist.png", width = 158, height = 93, units = "mm")

# --------------------------------------------------
# Valor inicial ----

#Correlacao
#Estimativas

a.0<-sin(cor(M,MI, method = "kendal")*pi/2) #Correlacao de kendal
a.0
start<- c(a.0)
udat<- cbind(pgev(M, qsi= qsi1, sigma= sigma1, mu= mu1),
             pgev(MI,qsi =qsi2, sigma= sigma2, mu= mu2))


myCop.clayton<- claytonCopula(dim=2)
myCop.gumbel<-gumbelCopula(dim=2)
myCop.frank<- frankCopula(dim=2)


fit.if1 <-fitCopula(myCop.clayton,udat, start=a.0)
fit.if1
fit.if2 <-fitCopula(myCop.gumbel,udat, start=a.0)
fit.if2
fit.if3 <-fitCopula(myCop.frank,udat, start=a.0)
fit.if3

library(copula)
cc<- claytonCopula(0.3275587)
sample1<- rCopula(10000, cc)
gu<- gumbelCopula(1.057)
sample2<- rCopula(10000,gu)
fr<- frankCopula(1.304)
sample3<- rCopula(10000,fr)

#Aic e BIC
aicCalyton <- -2*fit.if1@loglik+2
bicCalyton <- -2*fit.if1@loglik+log(10000)

aicGumbel <- -2*fit.if2@loglik+2
bicGumbel <- -2*fit.if2@loglik+log(10000)

aicFrank <- -2*fit.if3@loglik+2
bicFrank <- -2*fit.if3@loglik+log(10000)

#Adequacao do ajuste
aicCalyton
bicCalyton
aicFrank
bicFrank
aicGumbel
bicGumbel

# --------------------------------------------------
# Escolhemos aquela copula com menor AIC ----

n<- 1000
fr<- frankCopula(1.304)
sample<- rCopula(1000,fr)
plot(sample, xlab="U", ylab="V", pch = ".", cex = 1.5)

x<- numeric(n)
y<- numeric(n)

for (i in 1:n ){
  x[i] <- mu1 + sigma1*( ((-log(sample[i,1]))^(-qsi1) - 1 )/ qsi1 )
  y[i] <- mu2 + sigma2*( ((-log(sample[i,2]))^(-qsi2) - 1 )/ qsi2 )
}

par(mfrow=c(1,2))
plot(sample, xlab="U", ylab="V", pch = ". ", cex = 3,col="#00688B", main="Copula Frank")
plot(x, y, ylab="Y", pch = ". ", cex = 3, col="black", main="Frank marginal GEV " )
dev.off()

ggplot(mapping = aes(x = x, y = y)) +
  stat_density2d() + geom_point()

plot(M, MI, pch = ". ", cex = 5 , col="#00688B", xlab=" " , ylab=" " )
points(x, y, ylab="Y", pch = ". ", cex = 5, col="black")
legend("topright", legend=c("Dados simulados", "Dados reais"), col=c("black","#00688B"), pch = 15)

ggplot() +
  stat_density2d(mapping = aes(x = x, y = y), color = "black") +
  stat_density2d(mapping = aes(x = M, y = MI), color = "blue") +
  theme_classic() +
  labs(x="", y="")
ggsave("t2dens.png", width = 158, height = 93, units = "mm")

tau(fr)
rho(fr)
lambda(fr)

# --------------------------------------------------
# VAR ----
# VAR BIvARIADO tipo Expected Shortfall condicional 
# VAR NO OCTANTE INFERIOR

#Primeira componente do VaR bivariado com copula e marginais GEV
#(Se X~F_1=GEV_1-> primeira componente do VaR)

alpha= 0.95# alpha%
theta= 1.304 # valor estimado do parametro da copula
#mu # paraetro de locacao da marginal GEV
#sigma # parametro de escala da marginal GEV
#qsi parametro de forma da marginal GEV


#Gerar amostra de tamanho n=50 de uma va S~Beta(1,1)=U[0,1]

S<-runif(50, min=0, max=1)
S
# Para copula Frank 
# Definir o gerador da copula vphi(alpha)=vphi -> S*vphi(alpha)=S*vphi=t
vphi<- (-log(( exp(-theta*alpha)-1)/(exp(-theta)-1 )))
t<- S*vphi
t
#Definir a inversa de vphi(t) -> vphi^{-1}(S*vphi(alpha))=inv(t)=inv

inv<- (-theta^(-1))*log(1+exp(-t)*(exp(-theta) -1 ) )
inv

#Definir quantile F^(-1) da GEV -> F^{-1}(vphi^{-1}(S*vphi(alpha)))=F^{-1}(inv)=qgev
qev1<- mu1-(sigma1/qsi1)*(1-(-log(inv)))^(-qsi1)
qev1
qev2<- mu2-(sigma2/qsi2)*(1-(-log(inv)))^(-qsi2)
qev2

#Media E(F^{-1}(vphi^{-1}(S*vphi(alpha))))=VaR_1 componnete 1
(VAR <- c(mean(qev1), mean(qev2)))

#97,5
alpha= 0.975
theta= 1.304 
S<-runif(50, min=0, max=1)
vphi<- (-log(( exp(-theta*alpha)-1)/(exp(-theta)-1 )))
t<- S*vphi
inv<- (-theta^(-1))*log(1+exp(-t)*(exp(-theta) -1 ) )
qev1<- mu1-(sigma1/qsi1)*(1-(-log(inv)))^(-qsi1)
qev2<- mu2-(sigma2/qsi2)*(1-(-log(inv)))^(-qsi2)
(VAR <- c(mean(qev1), mean(qev2)))

#99
alpha= 0.99
theta= 1.304
S<-runif(50, min=0, max=1)
vphi<- (-log(( exp(-theta*alpha)-1)/(exp(-theta)-1 )))
t<- S*vphi
inv<- (-theta^(-1))*log(1+exp(-t)*(exp(-theta) -1 ) )
qev1<- mu1-(sigma1/qsi1)*(1-(-log(inv)))^(-qsi1)
qev2<- mu2-(sigma2/qsi2)*(1-(-log(inv)))^(-qsi2)
(VAR <- c(mean(qev1), mean(qev2)))



dbgumbel(M, mu1, sigma1, qsi1)
m1bgumbel(mu1, sigma1, qsi1)
m2bgumbel(mu1, sigma1, qsi1)
mlebgumbel(M, 1.057)
